nohup /usr/local/bin/python ./KunMing_ETC_jinfeng.py  > /dev/null 2>&1 & 
