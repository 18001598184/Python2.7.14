nohup /usr/local/bin/python ./KunMing_Dev_Status.py  > /dev/null 2>&1 & 
