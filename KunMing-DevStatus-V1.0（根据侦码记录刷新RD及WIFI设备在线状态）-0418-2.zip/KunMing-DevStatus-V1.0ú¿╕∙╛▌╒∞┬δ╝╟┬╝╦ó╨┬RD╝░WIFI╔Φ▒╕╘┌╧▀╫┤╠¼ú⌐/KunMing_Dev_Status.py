#coding:utf-8
import re,os,sys,time,logging
import cx_Oracle
import datetime
import ConfigParser
import binascii



####################################################
#     2G/4G/WIFI Device_status v1.0                #
#   Created by wangzhengyu @ 2020-4-18             #
#                                                  #
#                                                  #
#  +---------------------------------+             #
#  | Only for 2G/4G/WIFI data  file !|             #
#  +---------------------------------+             #
#                                                  #
####################################################


os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.ZHS16GBK'


def fun_set_logger(log_file):
    logger.setLevel(logging.DEBUG)
    LOG_FORMAT = "[%(asctime)s]-[%(levelname)s] %(message)s"
    
    DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

    # output log to file
    logger_FileHandler = logging.FileHandler(log_file)
    logger_FileHandler.setFormatter(logging.Formatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT))
    logger_FileHandler.setLevel(logging.DEBUG)
    logger.addHandler(logger_FileHandler)
    # output log to command-line console
    logger_StreamHandler = logging.StreamHandler()
    logger_StreamHandler.setFormatter(logging.Formatter(fmt=LOG_FORMAT, datefmt=DATE_FORMAT))
    logger_StreamHandler.setLevel(logging.INFO)
    logger.addHandler(logger_StreamHandler)


def update_rd_db(db,filename):

    rd_org_file =  filename
    f = file(rd_org_file)
    P001 = []

    while True:
        line = f.readline()	
        if len(line) ==0: # Zero length indicates EOF
            #print "Line'length is Zero,break \n"
    	    break
        elif len(line) < 50:
            #print line
            #print "Line's length is less tha 50,continue next loop.\n" 
            continue
	
        line = line.strip('\n').strip('\r')
        #print line
        #08-26 09:15:00:267 INFO[ZHANMA] - 8C147D4000DEB39M,
        #5,2017-08-26 09:14:40,460004990354307,000000000000000,
        #112.704662,23.345447,2017-08-26 09:14:40,12,1503710080,111,40,8C147D4000DE,TRSNJ20W004HD1.0,1001,46000,1353499
        try:   
            (filter,device_type,starttime,imsi,imei,\
                device_longitude,device_latitude,detecttime,device_mode,tmsi,rssi,band,mac,registered_code,vendor_id,plmn,tel_number) = line.split(',')
        except:
            logger.info("This line unpacked error:" + line)
            continue

        # 检查数据有效性
        # check the data valid         

        #registered_code	长度[1,50]
        if not (len(registered_code) >1 and len(registered_code) <50) :
            logger.info("the registered_code  is error:"+line)            
            continue

        
        #2018-02-07 18:14:44       
        #starttime        	日期（年月日时分秒）
      
        starttime =""

        #2018-02-07 18:14:44       
        #detecttime        	日期（年月日时分秒）
        try: 
            ts = time.strptime(detecttime, "%Y-%m-%d %H:%M:%S")
            Y,m,d,H,M,S = ts[0:6] 
            detecttime = datetime.datetime(Y,m,d,H,M,S) 
        except:
            logger.info("The detecttime format is error :"+line)            
            continue

        now = datetime.datetime.now()
        delta = now - detecttime
         
        #if ( detecttime > now or delta.seconds > 3600 ):
            #zm时间超过当前时间,或10分钟之前的数据
            #continue
            
        #else:
            #if not (registered_code in P001):
                #P001.append((registered_code))
        
        if not (registered_code in P001):
            P001.append((registered_code))

    f.close()# close the file
    
        #-----insert into db and commit   -------#
    cursor = db.cursor()         

    #update 4G device_status
    for registered_code in P001 :
        try:
            my_sql1 = 'update device_registered_info set device_status = 0 where REGISTERED_CODE = '
            my_sql1 += '\'' + registered_code + '\''
            my_sql2 = 'update device_registered_info set OFFTIME = sysdate where REGISTERED_CODE = '
            my_sql2 += '\'' + registered_code + '\''
            #print my_sql1
            #print my_sql2
            cursor.execute(my_sql1)
            cursor.execute(my_sql2)
        except  Exception as e:  
            logger.info("update rd device_status SQL_ERR :"+str(e))                    
            db.rollback() 
            return  -1   #error
            
        db.commit()

    return 0   #right    


def update_wifi_db(db,filename):

    wifi_org_file =  filename
    f = file(wifi_org_file)
    i_line = 0
    P002 = []

    while True:
        line = f.readline()	
        if len(line) ==0: # Zero length indicates EOF
            #print "Line'length is Zero,break \n"
    	    break
        elif len(line) < 10:
            #print line
            #print "Line's length is less tha 50,continue next loop.\n" 
            continue
        
	i_line = i_line + 1
        line = line.strip('\n').strip('\r')
        temp_array =  line.split(',')
        #-------- to decide which datatype of the line ---------------#
        try:
            #print "line:%d,key:s%" % (i_line,temp_array[1])
            temp = temp_array[1]
        except:
            print "Get key word error:line:%d::%s" % (i_line,line)
            continue

        
        if (temp_array[1] =='mac'):
            #------ P1001 mac  -------#
            # gwmac,stamac,apmac,stapower,essid,ctime
            try: 
                (filter1,filter2,\
                 gwmac,stamac,apmac,stapower,essid,detecttime\
                 ) = line.split(',')
            except:
                print "The line unpacked MAC error:line:%d::%s" % (i_line,line)
                continue
            if not (gwmac in P002):
                P002.append((gwmac))
                
        elif (temp_array[1] =='apmac'):
            #------ P1002  apmac-------#
            #08-28 17:21:44:363 INFO[NJ_COLLECT] - ,714666111B0385001C6BC,1002,
            # gwmac,apmac,channel,appower,essid,privacy,ctime
            try: 
                (filter1,filter2,\
                 gwmac,apmac,channel,appower,essid,privacy,detecttime\
                 ) = line.split(',')
            except:
                print "The line unpacked APMAC error:line:%d::%s" % (i_line,line)
                continue
            if not (gwmac in P002):
                P002.append((gwmac))
                
        elif (temp_array[1] =='MacEID'):
            #------ 9001  -------#
            #08-28 17:21:30:814 INFO[NJ_COLLECT] - ,714666111B0385001C6BC,9001,
            #gwmac,stamac,etype,evalue,ctime
            try: 
                (filter1,filter2,\
                 gwmac,stamac,etype,evalue,detecttime\
                 ) = line.split(',')
            except:
                print "The line unpacked MacEID error:line:%d::%s" % (i_line,line)
                continue
            if not (gwmac in P002):
                P002.append((gwmac))

    f.close()# close the file
    
        #-----insert into db and commit  -------#
    cursor = db.cursor()         

    #update WIFI device_status
    for gwmac in P002 :
        try:
            my_sql1 = 'update device_registered_info set device_status = 0 where REGISTERED_CODE = '
            my_sql1 += '\'' + gwmac + '\''
            my_sql2 = 'update device_registered_info set OFFTIME = sysdate where REGISTERED_CODE = '
            my_sql2 += '\'' + gwmac + '\''
            #print my_sql1
            #print my_sql2
            cursor.execute(my_sql1)
            cursor.execute(my_sql2)
        except  Exception as e:  
            logger.info("update wifi device_status SQL_ERR :"+str(e))                    
            db.rollback() 
            return  -1   #error
            
        db.commit()

    return 0   #right    


def round_query(rd_org_path,wifi_org_path,bak_path):
    rd_file_list = []
    wifi_file_list = []
    bufsize = 2048
    i = 0
    j = 0
    try: 	    
        rd_file_list=os.listdir(rd_org_path)
        wifi_file_list=os.listdir(wifi_org_path)
    except:

        logger.info("list local dir error ... \n")                    
        return -1
       
    rd_file_count =  len(rd_file_list)
    wifi_file_count =  len(wifi_file_list)
    logger.info("RD file number:"+str(rd_file_count))
    logger.info("WIFI file number:"+str(wifi_file_count))
    

    for ii in rd_file_list:
        
        #  T_DATADETECT_INFO201706101507.log

        rdmatchObj = re.match( r'^(.*\.log.COMPLETED)$', ii,re.M|re.I)
        #rdmatchObj = re.match( r'^(.*\.log)$', ii,re.M|re.I)
        if rdmatchObj:
            i += 1
            rd_org_file = rd_org_path+'/'+rdmatchObj.group(1)
            rename_file = bak_path +'/'+rdmatchObj.group(1)
            #print "[%d/%d] Doing file %s," % (i,file_count,org_file)
            logger.info("["+str(i)+"]/["+str(rd_file_count)+"] Doing file "+ rd_org_file)  
            r = update_rd_db(db,rd_org_file) 
            #print "return code is : %d\n" % r
            if (r == 0 ):
                try:
                    os.rename(rd_org_file,rename_file)
                    logger.info("      ---- good job!")  
                except:
                    logger.info("      ---- rename error,will suffix with 'rename'!")  
                    os.rename(rd_org_file,rename_file+'.rename')
                    continue
            else:
                logger.info("      ---- something wrong with db, rollback it!")

    for jj in wifi_file_list:
        
        #  WIFI_INFO201706101507.log

        wfmatchObj = re.match( r'^(.*\.log.COMPLETED)$', jj,re.M|re.I)
        #wfmatchObj = re.match( r'^(.*\.log)$', jj,re.M|re.I) 
        if wfmatchObj:
            j += 1
            wifi_org_file = wifi_org_path+'/'+wfmatchObj.group(1)
            rename_file = bak_path +'/'+wfmatchObj.group(1)
            #print "[%d/%d] Doing file %s," % (i,file_count,org_file)
            logger.info("["+str(j)+"]/["+str(wifi_file_count)+"] Doing file "+ wifi_org_file)  
            t = update_wifi_db(db,wifi_org_file) 
            #print "return code is : %d\n" % r
            if (t == 0 ):
                try:
                    os.rename(wifi_org_file,rename_file)
                    logger.info("      ---- good job!")  
                except:
                    logger.info("      ---- rename error,will suffix with 'rename'!")  
                    os.rename(wifi_org_file,rename_file+'.rename')
                    continue
            else:
                logger.info("      ---- something wrong with db, rollback it!")  
    

def connect_db():
    db_string = config.get("DB", "db_string")
    try:
        db = cx_Oracle.connect(db_string)
        return db
    except  Exception as e: 
        logger.info("Connect DB error:" +str(e))
        return -1



if __name__ == "__main__":

    db_config = "KunMing_Dev_Status.ini"
     
    log_file  = sys.argv[0]+".log"
    logger = logging.getLogger()
    fun_set_logger(log_file)
    if ( not os.path.isfile(db_config)):    
        logger.info(" I need the config file to run : KunMing_4G_Status.ini !\n")        
        exit()

    config = ConfigParser.ConfigParser()
    config.read(db_config)                
    rd_org_dir = config.get("DB", "rd_org_dir")
    wifi_org_dir = config.get("DB", "wifi_org_dir")
    bak_dir = config.get("DB", "bak_dir")

    db = []
    while True:
        
        if (db):   
            round_query(rd_org_dir,wifi_org_dir,bak_dir)
            logger.info("sleep 5 seconds ...\n")            
            time.sleep(5) 
        else:
            logger.info(" Connect to  DB ....")            
            db = connect_db()

