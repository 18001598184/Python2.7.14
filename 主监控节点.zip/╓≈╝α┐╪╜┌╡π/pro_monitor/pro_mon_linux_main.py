#coding:utf-8
import time,datetime,os,sys
import psutil,commands
import cx_Oracle
import ConfigParser
import requests
import paramiko
import threading

# Name: PRO_MON_LINUX
# Version = 1.0
# Author = wangzhengyu
# Create date =2020/04/04

# Version = 2.0
# Modify date =2020/04/05
# Add upload function

#os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'


def send_msg(check_msg):
	
    # --------  SEND  MSG----------------------
    #        It should send a msg at  8:10 whether there has error or not
    #        and other time ,just send error msg
    #------------------------------------------

    my_time = time.strftime("%H:%M:%S", time.localtime())
    my_hour = int(my_time[0:2])
    my_min  = int(my_time[3:5])
    
    #url_wx = 'http://58.213.29.51:18098/TranRunsTX/servlet/WeiXiServlet'
    #url_sms = 'http://58.213.29.51:18098/TranRunsTX/servlet/SmsServlet'
    #s = {'phone': '13952008822', 'message': 'Hello','source':'1'}
    #r = requests.post(url, data=s)
    #print r
        #print "encoding_orig:",chardet.detect(check_msg)
        #.encode('utf-8')
        #encoding =  chardet.detect(check_msg)['encoding']
        #check_msg.decode(encoding).encode('utf-8')
        #print "encoding:",chardet.detect(check_msg)
    
    #print code
    #print check_msg
    
    if (my_hour == 8 and my_min > 1 and my_min <15 and code == 0):
        check_msg = 'All Servers Running OK!!!'
        try:
            for my_phone in  phone_list:		    
	        s = {'phone':my_phone,'message':check_msg,'source':'1'}
	        r = requests.post(my_url,data=s)
	        print r
        except  Exception as e:  
	    print  'Send msg  error:'
	    print str(e)
        
    if (code > 0):  
        try:
            for my_phone in  phone_list:		    
	        s = {'phone':my_phone,'message':check_msg,'source':'1'}
	        r = requests.post(my_url,data=s)
	        print r
        except Exception as e:  
	    print 'Send msg error:'
	    print str(e)


def ssh2(ip,port,username,passwd):

    global check_msg
    global code
    
    try:
        transport = paramiko.Transport((ip,int(port)))
        transport.connect(username=username,password=passwd)
        sftp = paramiko.SFTPClient.from_transport(transport)
        #将pro_mon_linux_cli.py 上传至待检查服务器 /home/pro_monitor/pro_mon_linux_cli.py
        sftp.put(local_path, remote_path)
        #将remove_path 下载到本地 local_path
        #sftp.get('remove_path', 'local_path')
        #sftp.mkdir("/home/userdir", 0755)
        #删除目录
        #sftp.rmdir("/home/userdir")
        #文件重命名
        #sftp.rename("/home/test.sh", "/home/testfile.sh")
        #打印文件信息
        #print sftp.stat("/home/testfile.sh")
        #打印目录列表
        #print sftp.listdir("/home")
        transport.close()
    except Exception as e:
        print str(e)
        
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip,int(port),username,passwd,timeout=5)
        #cmd = "source /etc/profile && cd /home/oracle/pro_monitor/ && python pro_mon_linux-cli.py 2>&1"
        stdin, stdout, stderr = ssh.exec_command(cmd)
        #stdin.write("Y")   #简单交互，输入 ‘Y’ 
        out = stdout.readlines()
        #屏幕输出
        i = 1
        a = {}
        for o in out:
            a[i]=o
            i += 1
        #删除检查脚本pro_mon_linux_cli.py
        #stdin, stdout, stderr = ssh.exec_command("rm -rf" + str(remote_path))
        ssh.close()
    except Exception as e:
        print str(e)
        
    code += int(a[1])
    check_msg += a[2]
    #print code,check_msg]

if __name__ == "__main__":
    global is_debug
    global check_msg 
    global code
    global msg_phone
    global phone_list
    global my_url
    global cmd
    
    code = 0
    check_msg = ''
    threads = []
    
    config_file = "config.ini" 
    if ( not os.path.isfile(config_file)):    
        print " I need the config file to run : config.ini !\n"
        exit()

    config = ConfigParser.ConfigParser()
    config.read(config_file)
    #读取手机号码，多个手机号用","分开
    msg_phone = config.get("CHK_CONFIG", "msg_phone")        
    phone_list = msg_phone.split(',')
    #读取短息接口url
    my_url = config.get("CHK_CONFIG","url")
    #读取远程脚本执行指令
    cmd = config.get("CHK_CONFIG","cmd")
    #读取本地待上传文件全路径
    local_path = config.get("CHK_CONFIG","local_path")
    #读取远程待上传文件全路径
    remote_path = config.get("CHK_CONFIG","remote_path")
    
    
    host_file = "hosts.ini"
    if ( not os.path.isfile(host_file)):    
        print " I need the hosts file to run : hosts.ini !\n"
        exit()

    f = file(host_file)
    i = 1
    now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    print ""
    print "==================="
    print now_time
    print "==================="

    while True:
        line = f.readline()
        if not line:
            break
        
        #i = i+1
        line = line.strip('\n').strip('\r')
        try:   
            (ssh_host,ssh_port,ssh_username,ssh_passwd) = line.split(',')
        except:
            logger.info("This line unpacked error:" + line)
            continue
	#print i,ssh_host,ssh_port,ssh_username,ssh_passwd
        print i,'ssh',ssh_username+'@'+ssh_host,'-p',ssh_port
        i = i+1
        T = threading.Thread(target=ssh2,args=(ssh_host,ssh_port,ssh_username,ssh_passwd))
        T.start()
        threads.append(T)

    f.close() # close the file
    for t in threads:
        t.join()
    print "Checked Over!!!"
    print "check_code:" + str(code) + " check_msg:" + check_msg
    #print "check_msg:" + check_msg
    send_msg(check_msg)

    
   
