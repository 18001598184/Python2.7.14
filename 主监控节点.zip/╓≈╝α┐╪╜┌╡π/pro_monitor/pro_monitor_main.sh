#!/bin/sh
. /etc/profile
export mydate=`date +%Y%m%d`
export myfile=mon$mydate.log
echo $myfile
cd /home/pro_monitor

/usr/local/bin/python ./pro_mon_linux_main.py >> ./$myfile
